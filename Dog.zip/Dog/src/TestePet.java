
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

/**
 *
 * @author Fatec
 */
public class TestePet {


    public static void main(String[] args) {
        List<Caracteristicas> Caracteristicas = new ArrayList<>();
        List<Caracteristicas> raca = new ArrayList<>();
        List<Caracteristicas> peso = new ArrayList<>();
        List<Caracteristicas> nome = new ArrayList<>();

        try (Scanner scanner = new Scanner(System.in)) {
            System.out.print("Digite a raça: ");
            String  = scanner.nextLine();
            Caracteristicas.add(raca)
                    
                    System.out.print("Digite o peso: ");
                    double peso = scanner.nextDouble();
                    scanner.nextLine(); // Consumir o caractere de nova linha deixado pelo nextDouble()
                    Caracteristicas.add(peso)
                            
                            System.out.print("Digite o nome: ");
                            String nome = scanner.nextLine();
                            Caracteristicas.add(nome)
                                    
                                    
                                    
                                    
                                    }
    
    }
}
    

