
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

public class Caracteristicas {
    private double peso;
    private String raca;
    private String nome;
    
    

    public Caracteristicas(String raca, int peso, String nome){
        this.raca = raca;
        this.peso = peso;
        this.nome = nome;
}


    public double getPeso() {
        return peso;
    }


    public void setPeso(double peso) {
        this.peso = peso;
    }


    public String getRaca() {
        return raca;
    }


    public void setRaca(String raca) {
        this.raca = raca;
    }

    /**
     * @return the nome
     */
    public String getNome() {
        return nome;
    }

    /**
     * @param nome the nome to set
     */
    public void setNome(String nome) {
        this.nome = nome;
    }
    
    public void CadastrarNome(){
     List<Caracteristicas> nome = new ArrayList<>();
     Scanner scanner = new scanner(System.in);
     
     
}

    
    
}
